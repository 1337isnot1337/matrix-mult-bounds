; benchmark generated from python API
(set-info :status unknown)
(declare-fun y2 () Int)
(declare-fun y1 () Int)
(declare-fun y0 () Int)
(declare-fun eta0 () Real)
(declare-fun C0 () (Array Int Real))
(declare-fun eta1 () Real)
(declare-fun C1 () (Array Int Real))
(declare-fun C2 () (Array Int Real))
(assert
 (and (distinct y0 y1 y2) true))
(assert
 (let (($x15 (>= y0 0)))
 (and $x15 (< y0 3))))
(assert
 (let (($x19 (>= y1 0)))
 (and $x19 (< y1 3))))
(assert
 (let (($x22 (>= y2 0)))
 (and $x22 (< y2 3))))
(assert
 (= eta0 0.0))
(assert
 (or (> (- (+ 0.0 eta0) eta1) 0.0) (= (+ (* 1.0 (select C0 (+ y0 0)))) 0.0)))
(assert
 (or (> (- (+ 1.0 eta0) eta1) 0.0) (= (+ (* 1.0 (select C0 (+ y0 1)))) 0.0)))
(assert
 (let ((?x97 (+ (* 1.0 (select C0 (+ y1 0))))))
 (= ?x97 1.0)))
(assert
 (or (> (- (+ 1.0 eta1) eta1) 0.0) (= (+ (* 1.0 (select C0 (+ y1 1)))) 0.0)))
(assert
 (or (> (- (+ (- 1.0) eta1) eta1) 0.0) (= (+ (* 1.0 (select C0 (+ y2 0)))) 0.0)))
(assert
 (let ((?x132 (+ (* 1.0 (select C0 (+ y2 1))))))
 (= ?x132 1.0)))
(assert
 (let ((?x139 (+ (* 1.0 (select C1 (+ y0 0))))))
 (= ?x139 1.0)))
(assert
 (or (> (- (+ 1.0 eta0) eta0) 0.0) (= (+ (* 1.0 (select C1 (+ y0 1)))) 0.0)))
(assert
 (let ((?x157 (- (+ 0.0 eta1) eta0)))
 (let (($x158 (> ?x157 0.0)))
 (or $x158 (= (+ (* 1.0 (select C1 (+ y1 0)))) 0.0)))))
(assert
 (or (> (- (+ 1.0 eta1) eta0) 0.0) (= (+ (* 1.0 (select C1 (+ y1 1)))) 0.0)))
(assert
 (let ((?x119 (+ (- 1.0) eta1)))
 (let ((?x189 (- ?x119 eta0)))
 (let (($x190 (> ?x189 0.0)))
 (or $x190 (= (+ (* 1.0 (select C1 (+ y2 0)))) 0.0))))))
(assert
 (let ((?x157 (- (+ 0.0 eta1) eta0)))
 (let (($x158 (> ?x157 0.0)))
 (or $x158 (= (+ (* 1.0 (select C1 (+ y2 1)))) 0.0)))))
(assert
 (or (> (- (+ (- 1.0) eta0) eta0) 0.0) (= (+ (* 1.0 (select C2 (+ y0 0)))) 0.0)))
(assert
 (let ((?x223 (+ (* 1.0 (select C2 (+ y0 1))))))
 (= ?x223 1.0)))
(assert
 (let ((?x119 (+ (- 1.0) eta1)))
 (let ((?x189 (- ?x119 eta0)))
 (let (($x190 (> ?x189 0.0)))
 (or $x190 (= (+ (* 1.0 (select C2 (+ y1 0)))) 0.0))))))
(assert
 (let ((?x157 (- (+ 0.0 eta1) eta0)))
 (let (($x158 (> ?x157 0.0)))
 (or $x158 (= (+ (* 1.0 (select C2 (+ y1 1)))) 0.0)))))
(assert
 (or (> (- (+ (- 2.0) eta1) eta0) 0.0) (= (+ (* 1.0 (select C2 (+ y2 0)))) 0.0)))
(assert
 (let ((?x119 (+ (- 1.0) eta1)))
(let ((?x189 (- ?x119 eta0)))
(let (($x190 (> ?x189 0.0)))
(or $x190 (= (+ (* 1.0 (select C2 (+ y2 1)))) 0.0))))))
(check-sat)
